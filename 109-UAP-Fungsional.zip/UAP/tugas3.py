def tambah_angka(angka, total = 0):
    return total+angka

coba = tambah_angka(1)

print(coba)

