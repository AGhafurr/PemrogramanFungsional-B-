klasifikasi_angka = lambda x: "positif" if x > 0 else ("Negatif" if x < 0 else "Nol")

result = klasifikasi_angka(5)
print(result)