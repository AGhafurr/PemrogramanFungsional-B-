ganjil= [x for x in range(0, 50) if x % 2 != 0]


print(ganjil)